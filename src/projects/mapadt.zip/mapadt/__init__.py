#!/usr/bin/env python3
"""
`mapadt` package

@authors: Roman Yasinovskyy
@version: 2021.3
"""


from .mapadt import HashMap

__all__ = ["HashMap"]
